/**
 * Implementation of CheXpeditor server. This application communicates with the CheXpeditor client
 * when running in auto mode to automatically capture and store the photos displayed on the screen.
 */
package io.github.stanfordmlgroup.chexpeditor;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CheXpeditorActivity extends Activity {

    private final static String TAG = CheXpeditorActivity.class.getSimpleName();

    UdpServerThread udpServerThread;

    Button startButton;
    TextView statusTextView;
    TextView logTextView;
    EditText portEditText;
    EditText seqEditText;
    ImageView previewImageView;
    boolean running;
    int mySeq;
    Camera camera;
    SurfaceTexture surfaceTexture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startButton = (Button) findViewById(R.id.button_start);
        statusTextView = (TextView) findViewById(R.id.textview_status);
        logTextView = (TextView) findViewById(R.id.textview_log);
        logTextView.setMovementMethod(new ScrollingMovementMethod());
        portEditText = (EditText) findViewById(R.id.edittext_port);
        portEditText.setTransformationMethod(null);
        seqEditText = (EditText) findViewById(R.id.edittext_seq);
        seqEditText.setTransformationMethod(null);
        previewImageView = (ImageView) findViewById(R.id.imageview_preview);
        running = false;
        updateState("UDP Server is stopped");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        camera = getCameraInstance();
    }

    // Get the camera instance
    public static Camera getCameraInstance() {
        Camera c = null;
        try {
            c = Camera.open(); // Attempt to get a Camera instance
            // Source: https://stackoverflow.com/questions/15623944/how-to-autofocus-android-camera-automatically
            Camera.Parameters params = c.getParameters();
            params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            c.setParameters(params);
        } catch (Exception e) {
            Log.e(TAG, "Camera not available!");
        }
        return c;
    }

    // Take a photo using the camera, and store it under the given filename
    // Source: https://stackoverflow.com/questions/14241294/take-picture-automatically-with-no-user-interaction
    protected void takePhoto(final String filename, Context context) {
        surfaceTexture = new SurfaceTexture(0);

        try {
            camera.setPreviewTexture(surfaceTexture);
            camera.startPreview();
            camera.takePicture(null, null, new Camera.PictureCallback() {
                @Override
                public void onPictureTaken(byte[] bytes, Camera camera) {
                    // Source: https://stackoverflow.com/questions/7978905/android-java-saving-a-byte-array-to-a-file-jpeg
                    File dir = new File(Environment.getExternalStorageDirectory() + "/CheXpeditor");
                    dir.mkdirs();
                    File photo = new File(dir, filename);
                    try {
                        FileOutputStream fos = new FileOutputStream(photo.getPath());
                        fos.write(bytes);
                        fos.close();
                    } catch (java.io.IOException e) {
                        Log.e(TAG, "Exception in photoCallback", e);
                    }

                    // Source: https://stackoverflow.com/questions/13854742/byte-array-of-image-into-imageview
                    Log.e(TAG, "Displaying image.");
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    ImageView image = (ImageView) findViewById(R.id.imageview_preview);
                    float scale = Math.min((float) image.getWidth() / bmp.getWidth(), (float) image.getHeight() / bmp.getHeight());
                    int newWidth = (int) (scale * bmp.getWidth());
                    int newHeight = (int) (scale * bmp.getHeight());
                    image.setImageBitmap(Bitmap.createScaledBitmap(bmp, newWidth, newHeight, false));
                    Log.e(TAG, "Done displaying image.");
                    udpServerThread.sem.release();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Start the UDP server at the specified port
    protected void startServer(int port) {
        udpServerThread = new UdpServerThread(port);
        udpServerThread.start();
    }

    // Stop the server
    protected void stopServer() {
        if (udpServerThread != null) {
            if (udpServerThread.socket != null) {
                udpServerThread.socket.close();
            }
            udpServerThread.interrupt();
            udpServerThread = null;
        }
    }

    // Source: https://stackoverflow.com/questions/8714814/android-closing-the-camera-correctly
    @Override
    protected void onPause() {
        super.onPause();
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
        startButton.setText("Start");
        stopServer();
        updateState("UDP Server is stopped");
        seqEditText.setEnabled(true);
        portEditText.setEnabled(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        camera = getCameraInstance();
    }

    private void updateState(final String state) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusTextView.setText(state);
            }
        });
    }

    // Log some information into the app UI
    private void updatePrompt(final int seq, final String prompt) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                logTextView.append("[" + seq + "]: " + prompt + "\n");
            }
        });
    }

    // Start and stop the server when the button is pressed
    public void toggleButton(View view) {
        if (!running) {
            String portString = portEditText.getText().toString();
            if (portString.length() == 0) return;
            String seqString = seqEditText.getText().toString();
            if (seqString.length() == 0) return;
            int port = Integer.parseInt(portString);
            mySeq = Integer.parseInt(seqString);
            startButton.setText("Stop");
            startServer(port);
            seqEditText.setEnabled(false);
            portEditText.setEnabled(false);
        } else {
            startButton.setText("Start");
            stopServer();
            updateState("UDP Server is stopped");
            seqEditText.setEnabled(true);
            portEditText.setEnabled(true);
        }
        running = !running;
    }

    // Clear the logs when the button is pressed
    public void clearButton(View view) {
        logTextView.setText("");
        ImageView image = (ImageView) findViewById(R.id.imageview_preview);
        image.setImageResource(android.R.color.transparent);
    }

    // Simple implementation of a UDP server in Android
    // Source: http://android-er.blogspot.com/2016/06/android-datagramudp-server-example.html
    private class UdpServerThread extends Thread implements Runnable {

        int serverPort;
        DatagramSocket socket;
        final Lock lock = new ReentrantLock();
        final Semaphore sem = new Semaphore(0);

        boolean running;

        public UdpServerThread(int serverPort) {
            super();
            this.serverPort = serverPort;
        }

        @Override
        public void run() {

            running = true;

            try {
                updateState("Starting UDP Server");
                socket = new DatagramSocket(serverPort);

                updateState("UDP Server is running on " + getIpAddress() + ":" + serverPort);
                Log.e(TAG, "UDP Server is running on " + getIpAddress() + ":" + serverPort);

                while (running) {
                    byte[] buf = new byte[256];

                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    socket.receive(packet);

                    InetAddress address = packet.getAddress();
                    int port = packet.getPort();
                    String message = new String(packet.getData(), 0, packet.getLength());
                    String[] parts = message.split("\\|");
                    int seq = Integer.parseInt(parts[0]);
                    if (seq == mySeq) {
                        updatePrompt(seq, "Received " + parts[1]);
                        mySeq++;
                        takePhoto(parts[1], getApplicationContext());
                        lock.lock();
                        try {
                            sem.acquire(1);
                        } catch (InterruptedException e) {
                            lock.unlock();
                            socket.close();
                            socket = null;
                            return;
                        } finally {
                            lock.unlock();
                        }
                        updatePrompt(seq, "Wrote " + parts[1]);
                        String dString = "OK|" + parts[1];
                        buf = dString.getBytes();
                        packet = new DatagramPacket(buf, buf.length, address, port);
                        socket.send(packet);
                    } else {
                        updatePrompt(seq, parts[1] + " (MISMATCH!!)");
                        String dString = "MISMATCH";
                        buf = dString.getBytes();
                        packet = new DatagramPacket(buf, buf.length, address, port);
                        socket.send(packet);
                    }
                }
                Log.e(TAG, "UDP Server ended");

            } catch (SocketException e) {
                updateState("Socket closed.");
                Log.e(TAG, "socket.close()");
                socket = null;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (socket != null) {
                    socket.close();
                    Log.e(TAG, "socket.close()");
                }
            }
        }
    }

    // Get the IP address of the phone on the local network
    private String getIpAddress() {
        String ip = "";
        try {
            Enumeration<NetworkInterface> enumNetworkInterfaces = NetworkInterface
                    .getNetworkInterfaces();
            while (enumNetworkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = enumNetworkInterfaces
                        .nextElement();
                Enumeration<InetAddress> enumInetAddress = networkInterface
                        .getInetAddresses();
                while (enumInetAddress.hasMoreElements()) {
                    InetAddress inetAddress = enumInetAddress.nextElement();
                    if (inetAddress.isSiteLocalAddress()) {
                        ip += inetAddress.getHostAddress();
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return ip;
    }
}


